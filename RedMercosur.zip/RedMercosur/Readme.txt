Abrir RedMercosur.sln
Dentro del proyecto tenemos 
-BACK
-FRONT
Dentro de Back un Readme