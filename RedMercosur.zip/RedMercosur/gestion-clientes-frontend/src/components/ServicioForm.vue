<template>
  <div class="form-container">
    <h3>{{ servicio?.id ? "Editar Servicio" : "Agregar Servicio" }}</h3>
    <form @submit.prevent="onSubmit">
      <label for="nombre">Nombre</label>
      <input
        id="nombre"
        v-model="form.nombre"
        type="text"
        required
        placeholder="Nombre del servicio"
      />

      <label for="descripcion">Descripción</label>
      <textarea
        id="descripcion"
        v-model="form.descripcion"
        placeholder="Descripción del servicio"
      ></textarea>

      <button type="submit">{{ servicio?.id ? "Actualizar" : "Crear" }}</button>
      <button type="button" @click="$emit('close')">Cancelar</button>
    </form>
  </div>
</template>

<script>
import { addServicio, updateServicio } from "@/services/apiService";

export default {
  props: {
    servicio: {
      type: Object,
      default: null,
    },
  },
  data() {
    return {
      form: {
        nombre: "",
        descripcion: "",
      },
    };
  },
  watch: {
    servicio: {
      immediate: true,
      handler(newVal) {
        if (newVal) {
          this.form = {
            nombre: newVal.nombre || "",
            descripcion: newVal.descripcion || "",
            id: newVal.id, // id para edición
          };
        } else {
          this.form = {
            nombre: "",
            descripcion: "",
            id: null,
          };
        }
      },
    },
  },
  methods: {
    onSubmit() {
      if (this.form.id) {
        // Actualizar servicio
        updateServicio(this.form.id, {
          nombre: this.form.nombre,
          descripcion: this.form.descripcion,
        })
          .then(() => {
            alert("Servicio actualizado correctamente");
            this.$emit("saved");
            this.$emit("close");
          })
          .catch(() => alert("Error al actualizar servicio"));
      } else {
        // Crear servicio nuevo
        addServicio({
          nombre: this.form.nombre,
          descripcion: this.form.descripcion,
        })
          .then(() => {
            alert("Servicio creado correctamente");
            this.$emit("saved");
            this.$emit("close");
          })
          .catch(() => alert("Error al crear servicio"));
      }
    },
  },
};
</script>

<style scoped>
.form-container {
  max-width: 400px;
  margin: 20px auto;
  border: 1px solid #ddd;
  padding: 15px;
  border-radius: 5px;
}
form label {
  display: block;
  margin-top: 10px;
  font-weight: bold;
}
form input,
form textarea {
  width: 100%;
  padding: 8px;
  margin-top: 5px;
  box-sizing: border-box;
}
button {
  margin-top: 15px;
  margin-right: 10px;
  padding: 8px 16px;
  cursor: pointer;
}
</style>
