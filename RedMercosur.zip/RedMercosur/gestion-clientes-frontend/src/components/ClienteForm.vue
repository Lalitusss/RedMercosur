<template>
  <div>
    <h3>{{ cliente?.id ? 'Editar Cliente' : 'Agregar Cliente' }}</h3>
    <form @submit.prevent="onSubmit">
      <input v-model="form.nombre" placeholder="Nombre" required />
      <input v-model="form.apellido" placeholder="Apellido" required />
      <input v-model="form.telefono" placeholder="Teléfono" />
      <input v-model="form.direccion" placeholder="Dirección" />
      <select v-model="form.servicioId" required>
        <option value="" disabled>Seleccione Servicio</option>
        <option v-for="s in servicios" :key="s.id" :value="s.id">{{ s.nombre }}</option>
      </select>
      <label>
        <input type="checkbox" v-model="form.disponibilidad" /> Disponible
      </label>
       <div class="form-actions">
      <button type="submit">Guardar</button>
      <button type="button" @click="$emit('close')">Cancelar</button>
    </div>
    </form>
  </div>
</template>

<script>
import { addCliente, updateCliente } from '@/services/apiService';

export default {
  props: {
    cliente: Object,
    servicios: Array,
  },
  data() {
    return {
      form: {
        nombre: '',
        apellido: '',
        telefono: '',
        direccion: '',
        disponibilidad: false,
        servicioId: null,
      }
    };
  },
  watch: {
    cliente: {
      immediate: true,
      handler(newVal) {
        if(newVal) {
          this.form = { ...newVal }; // cubrir campos
        }
      }
    }
  },
  methods: {
    onSubmit() {
      if(this.form.id) {
        updateCliente(this.form.id, this.form).then(() => {
          alert('Cliente actualizado');
          this.$emit('saved');
          this.$emit('close');
        }).catch(() => alert('Error al actualizar'));
      }
      else {
        addCliente(this.form).then(() => {
          alert('Cliente creado');
          this.$emit('saved');
          this.$emit('close');
        }).catch(() => alert('Error al crear'));
      }
    }
  }
}
</script>
<style scoped>
label {
  display: inline-flex;
  align-items: center;
  gap: 0.4rem; /* separa el checkbox del texto */
  cursor: pointer;
}
</style>