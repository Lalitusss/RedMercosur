<template>
  <div>
    <h2>Servicios</h2>
    <button @click="openAddForm">Agregar Servicio</button>
    <table>
      <thead>
        <tr>
          <th>Nombre</th>
          <th>Descripción</th>
          <th>Acciones</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="servicio in servicios" :key="servicio.id">
          <td>{{ servicio.nombre }}</td>
          <td>{{ servicio.descripcion }}</td>
          <td>
            <button @click="openEditForm(servicio)">Editar</button>
            <button @click="deleteServicio(servicio.id)">Eliminar</button>
          </td>
        </tr>
      </tbody>
    </table>

    <!-- Formulario para agregar/editar servicio -->
    <ServicioForm 
      v-if="showForm" 
      :servicio="selectedServicio" 
      @close="closeForm" 
      @saved="fetchServicios"
    />
  </div>
</template>

<script>
import { getServicios, deleteServicio } from '@/services/apiService'
import ServicioForm from './ServicioForm.vue'

export default {
  name: 'ServicioLista',
  components: { ServicioForm },
  data() {
    return {
      servicios: [],
      showForm: false,
      selectedServicio: null,
    }
  },
  methods: {
    fetchServicios() {
      getServicios()
        .then(res => { this.servicios = res.data })
        .catch(() => alert('Error al cargar servicios'))
    },
    openAddForm() {
      this.selectedServicio = null
      this.showForm = true
    },
    openEditForm(servicio) {
      this.selectedServicio = { ...servicio }
      this.showForm = true
    },
    closeForm() {
      this.showForm = false
      this.selectedServicio = null
    },
    deleteServicio(id) {
      if (confirm('¿Eliminar servicio?')) {
        deleteServicio(id)
          .then(() => {
            alert('Servicio eliminado')
            this.fetchServicios()
          })
          .catch(() => alert('Error al eliminar servicio'))
      }
    }
  },
  mounted() {
    this.fetchServicios()
  }
}
</script>

<style scoped>
table {
  width: 80%;
  margin: 20px auto;
  border-collapse: collapse;
}
th, td {
  border: 1px solid #ddd;
  padding: 8px;
}
th {
  background-color: #f2f2f2;
}
button {
  margin-right: 5px;
  padding: 6px 12px;
  cursor: pointer;
}
</style>
