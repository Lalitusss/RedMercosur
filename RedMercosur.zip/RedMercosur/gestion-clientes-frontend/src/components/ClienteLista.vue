<template>
  <div>
    <h2>Clientes</h2>
    <button @click="openAddForm">Agregar Cliente</button>
    <table>
      <thead>
        <tr>
          <th>Nombre</th>
          <th>Apellido</th>
          <th>Telefono</th>
          <th>Dirección</th>
          <th>Servicio</th>
          <th>Disponibilidad</th> <!-- Aquí es donde se muestra el checkbox -->
          <th>Acciones</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="cliente in clientes" :key="cliente.id">
          <td>{{ cliente.nombre }}</td>
          <td>{{ cliente.apellido }}</td>
          <td>{{ cliente.telefono }}</td>
          <td>{{ cliente.direccion }}</td>
          <td>{{ cliente.servicioNombre }}</td>
          <!-- CAMBIO AQUÍ: Usar un checkbox deshabilitado y centrar -->
          <td style="text-align: center;">
            <input type="checkbox" :checked="cliente.disponibilidad" disabled />
          </td>
          <td>
            <button @click="openEditForm(cliente)">Editar</button>
            <button @click="onDelete(cliente.id)">Eliminar</button>
          </td>
        </tr>
      </tbody>
    </table>

    <cliente-form
      v-if="showForm"
      :cliente="selectedCliente"
      :servicios="servicios"
      @close="closeForm"
      @saved="fetchClientes"
    />
  </div>
</template>

<script>
import { getClientes, deleteCliente, getServicios } from '@/services/apiService';
import ClienteForm from './ClienteForm.vue';

export default {
  name: 'ClienteLista',
  components: { ClienteForm },
  data() {
    return {
      clientes: [],
      servicios: [],
      showForm: false,
      selectedCliente: null,
    };
  },
  methods: {
    fetchClientes() {
      getClientes()
        .then((response) => {
          this.clientes = response.data;
        })
        .catch(() => alert('Error al cargar clientes'));
    },
    fetchServicios() {
      getServicios().then((res) => {
        this.servicios = res.data;
      });
    },
    openAddForm() {
      this.selectedCliente = null;
      this.showForm = true;
    },
    openEditForm(cliente) {
      this.selectedCliente = { ...cliente };
      this.showForm = true;
    },
    closeForm() {
      this.showForm = false;
    },
    onDelete(id) {
      if (confirm('¿Eliminar cliente?')) {
        deleteCliente(id)
          .then(() => {
            alert('Cliente eliminado');
            this.fetchClientes();
          })
          .catch(() => alert('Error al eliminar'));
      }
    },
  },
  mounted() {
    this.fetchClientes();
    this.fetchServicios();
  },
};
</script>

<style scoped>
/* Opcional: Estilos para la tabla o botones si es necesario */
table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 20px;
}
th, td {
  border: 1px solid #ddd;
  padding: 8px;
  text-align: left; /* Mantener la alineación general a la izquierda */
}
th {
  background-color: #f2f2f2;
}
/* Asegúrate de que el checkbox no se vea afectado por text-align: left en td si lo pones global */
td input[type="checkbox"] {
  /* Si necesitas ajustar más, puedes añadir margin o padding aquí */
  vertical-align: middle; /* Para que se alinee verticalmente bien */
}
</style>
