import axios from 'axios';

const apiClient = axios.create({
  baseURL: 'https://localhost:5082/api', // Cambiar URL según backend
  headers: { 'Content-Type': 'application/json' },
});

export const getClientes = (servicioId) => {
  let url = '/clientes';
  if (servicioId) url += `?servicioId=${servicioId}`;
  return apiClient.get(url);
};

export const getClienteById = (id) => apiClient.get(`/clientes/${id}`);

export const addCliente = (cliente) => apiClient.post('/clientes', cliente);

export const updateCliente = (id, cliente) => apiClient.put(`/clientes/${id}`, cliente);

export const deleteCliente = (id) => apiClient.delete(`/clientes/${id}`);

export const getServicios = () => apiClient.get('/servicios');

export const addServicio = (servicio) => apiClient.post('/servicios', servicio);

export const updateServicio = (id, servicio) => apiClient.put(`/servicios/${id}`, servicio);

export const deleteServicio = (id) => apiClient.delete(`/servicios/${id}`);
