import { createRouter, createWebHistory } from 'vue-router'
import Clientes from '../components/ClienteLista.vue'
import Servicios from '../components/ServicioLista.vue'

const routes = [
  {
    path: '/', // Ruta principal
    name: 'ClienteLista',
    component: Clientes  
  },
  {
    path: '/servicios',  
    name: 'ServicioLista',
    component: Servicios  
  }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router

