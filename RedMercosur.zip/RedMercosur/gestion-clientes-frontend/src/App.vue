<template>
  <div id="app">
    <nav>
      <router-link to="/">Clientes</router-link> |
      <router-link to="/servicios">Servicios</router-link>
    </nav>
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App',
}
</script>

<style>
/* ... tus estilos existentes ... */
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
nav {
  padding: 30px;
}
nav a {
  font-weight: bold;
  color: #2c3e50;
}
nav a.router-link-exact-active {
  color: #42b983;
}
/* Agrega aquí los estilos de tablas, botones y formularios que has usado en otros componentes */
table {
  width: 80%;
  margin: 20px auto;
  border-collapse: collapse;
}
th, td {
  border: 1px solid #ddd;
  padding: 8px;
  text-align: left;
}
th {
  background-color: #f2f2f2;
}
button {
  padding: 8px 12px;
  margin: 5px;
  cursor: pointer;
}
form {
  margin-top: 20px;
  border: 1px solid #eee;
  padding: 20px;
  max-width: 500px;
  margin-left: auto;
  margin-right: auto;
  text-align: left;
}
form input, form select, form textarea {
  display: block;
  width: calc(100% - 20px);
  padding: 8px;
  margin-bottom: 10px;
}
</style>
