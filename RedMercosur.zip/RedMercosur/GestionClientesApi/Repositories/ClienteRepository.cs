﻿using Microsoft.EntityFrameworkCore;

public class ClienteRepository : IClienteRepository
{
    private readonly GestionClientesContext _context;

    public ClienteRepository(GestionClientesContext context)
    {
        _context = context;
    }

    public async Task<IEnumerable<Cliente>> GetAllAsync(int? servicioId = null)
    {
        var query = _context.Clientes.Include(c => c.Servicio).AsQueryable();

        if (servicioId.HasValue)
            query = query.Where(c => c.ServicioId == servicioId);

        return await query.ToListAsync();
    }

    public async Task<Cliente> GetByIdAsync(int id)
    {
        return await _context.Clientes.Include(c => c.Servicio).FirstOrDefaultAsync(c => c.Id == id);
    }

    public async Task AddAsync(Cliente cliente)
    {
        await _context.Clientes.AddAsync(cliente);
        await _context.SaveChangesAsync();
    }

    public async Task UpdateAsync(Cliente cliente)
    {
        _context.Clientes.Update(cliente);
        await _context.SaveChangesAsync();
    }

    public async Task DeleteAsync(int id)
    {
        var cliente = await _context.Clientes.FindAsync(id);
        if (cliente != null)
        {
            _context.Clientes.Remove(cliente);
            await _context.SaveChangesAsync();
        }
    }
}
