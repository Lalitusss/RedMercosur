﻿public class ClienteService : IClienteService
{
    private readonly IClienteRepository _clienteRepository;

    public ClienteService(IClienteRepository clienteRepository)
    {
        _clienteRepository = clienteRepository;
    }

    public Task<IEnumerable<Cliente>> GetAllAsync(int? servicioId = null) =>
        _clienteRepository.GetAllAsync(servicioId);

    public Task<Cliente> GetByIdAsync(int id) =>
        _clienteRepository.GetByIdAsync(id);

    public Task AddAsync(Cliente cliente) =>
        _clienteRepository.AddAsync(cliente);

    public Task UpdateAsync(Cliente cliente) =>
        _clienteRepository.UpdateAsync(cliente);

    public Task DeleteAsync(int id) =>
        _clienteRepository.DeleteAsync(id);
}
