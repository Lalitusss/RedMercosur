﻿public class ServicioService : IServicioService
{
    private readonly IServicioRepository _servicioRepository;

    public ServicioService(IServicioRepository servicioRepository)
    {
        _servicioRepository = servicioRepository;
    }

    public Task<IEnumerable<Servicio>> GetAllAsync()
        => _servicioRepository.GetAllAsync();

    public Task<Servicio> GetByIdAsync(int id)
        => _servicioRepository.GetByIdAsync(id);

    public Task AddAsync(Servicio servicio)
        => _servicioRepository.AddAsync(servicio);

    public Task UpdateAsync(Servicio servicio)
        => _servicioRepository.UpdateAsync(servicio);

    public Task DeleteAsync(int id)
        => _servicioRepository.DeleteAsync(id);
}
