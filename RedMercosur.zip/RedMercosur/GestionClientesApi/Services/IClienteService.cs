﻿public interface IClienteService
{
    Task<IEnumerable<Cliente>> GetAllAsync(int? servicioId = null);
    Task<Cliente> GetByIdAsync(int id);
    Task AddAsync(Cliente cliente);
    Task UpdateAsync(Cliente cliente);
    Task DeleteAsync(int id);
}
