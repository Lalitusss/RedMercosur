﻿using Microsoft.EntityFrameworkCore;

public class GestionClientesContext : DbContext
{
    public GestionClientesContext(DbContextOptions<GestionClientesContext> options) : base(options) { }

    public DbSet<Cliente> Clientes { get; set; }
    public DbSet<Servicio> Servicios { get; set; }
}
