﻿using System.ComponentModel.DataAnnotations;

public class ClienteUpdateDto
{
    [Required]
    public string Nombre { get; set; }
    public string Apellido { get; set; }
    public string Telefono { get; set; }
    public string Direccion { get; set; }
    public bool Disponibilidad { get; set; }
    [Required]
    public int ServicioId { get; set; }
}
