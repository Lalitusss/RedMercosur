﻿using System.ComponentModel.DataAnnotations;

public class ServicioUpdateDto
{
    [Required]
    public string Nombre { get; set; }
    public string? Descripcion { get; set; }
}
