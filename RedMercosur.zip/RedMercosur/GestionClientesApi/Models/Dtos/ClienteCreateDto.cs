﻿using System.ComponentModel.DataAnnotations;

public class ClienteCreateDto
{
    [Required]
    public string Nombre { get; set; }
    public string Apellido { get; set; }
    public string Telefono { get; set; }
    public string Direccion { get; set; }
    public bool Disponibilidad { get; set; } = true;
    [Required]
    public int ServicioId { get; set; }
}
