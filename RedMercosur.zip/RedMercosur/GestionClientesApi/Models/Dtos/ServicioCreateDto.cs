﻿using System.ComponentModel.DataAnnotations;

public class ServicioCreateDto
{
    [Required]
    public string Nombre { get; set; }
    public string? Descripcion { get; set; }
}
