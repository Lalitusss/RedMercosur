﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
public class ClientesController : ControllerBase
{
    private readonly IClienteService _clienteService;
    private readonly IMapper _mapper;
    private readonly ILogger<ClientesController> _logger;

    public ClientesController(
        IClienteService clienteService,
        IMapper mapper,
        ILogger<ClientesController> logger)
    {
        _clienteService = clienteService;
        _mapper = mapper;
        _logger = logger;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<ClienteDto>>> GetClientes([FromQuery] int? servicioId)
    {
        try
        {
            var clientes = await _clienteService.GetAllAsync(servicioId);

            // Mapea lista de entidad a lista de DTO
            var clientesDto = _mapper.Map<IEnumerable<ClienteDto>>(clientes);

            return Ok(clientesDto);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error al obtener clientes");
            return StatusCode(500, "Error interno del servidor al obtener clientes.");
        }
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<ClienteDto>> GetCliente(int id)
    {
        if (id <= 0)
            return BadRequest("El ID del cliente debe ser un valor positivo.");

        try
        {
            var cliente = await _clienteService.GetByIdAsync(id);
            if (cliente == null)
                return NotFound($"No se encontró cliente con ID {id}");

            var clienteDto = _mapper.Map<ClienteDto>(cliente);
            return Ok(clienteDto);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error al obtener cliente con ID {Id}", id);
            return StatusCode(500, "Error interno del servidor al obtener cliente.");
        }
    }

    [HttpPost]
    public async Task<ActionResult<ClienteDto>> CreateCliente([FromBody] ClienteCreateDto clienteCreateDto)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        try
        {
            var cliente = _mapper.Map<Cliente>(clienteCreateDto);
            await _clienteService.AddAsync(cliente);

            var clienteDto = _mapper.Map<ClienteDto>(cliente);

            return CreatedAtAction(nameof(GetCliente), new { id = cliente.Id }, clienteDto);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error al crear cliente");
            return StatusCode(500, "Error interno del servidor al crear cliente.");
        }
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateCliente(int id, [FromBody] ClienteUpdateDto clienteUpdateDto)
    {
        if (id <= 0)
            return BadRequest("El ID del cliente debe ser un valor positivo.");

        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        try
        {
            var existingCliente = await _clienteService.GetByIdAsync(id);
            if (existingCliente == null)
                return NotFound($"No se encontró cliente con ID {id}");

            // Mapear los cambios al cliente existente
            _mapper.Map(clienteUpdateDto, existingCliente);

            await _clienteService.UpdateAsync(existingCliente);

            return NoContent();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error al actualizar cliente con ID {Id}", id);
            return StatusCode(500, "Error interno del servidor al actualizar cliente.");
        }
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteCliente(int id)
    {
        if (id <= 0)
            return BadRequest("El ID del cliente debe ser un valor positivo.");

        try
        {
            var existingCliente = await _clienteService.GetByIdAsync(id);
            if (existingCliente == null)
                return NotFound($"No se encontró cliente con ID {id}");

            await _clienteService.DeleteAsync(id);

            return NoContent();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error al eliminar cliente con ID {Id}", id);
            return StatusCode(500, "Error interno del servidor al eliminar cliente.");
        }
    }
}
