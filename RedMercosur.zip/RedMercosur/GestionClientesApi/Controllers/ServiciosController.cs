﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
public class ServiciosController : ControllerBase
{
    private readonly IServicioService _servicioService;
    private readonly IMapper _mapper;
    private readonly ILogger<ServiciosController> _logger;

    public ServiciosController(
        IServicioService servicioService,
        IMapper mapper,
        ILogger<ServiciosController> logger)
    {
        _servicioService = servicioService;
        _mapper = mapper;
        _logger = logger;
    }

    [HttpGet]
    public async Task<ActionResult<List<ServicioDto>>> GetServicios()
    {
        try
        {
            var servicios = await _servicioService.GetAllAsync();

            var serviciosDto = _mapper.Map<List<ServicioDto>>(servicios);

            return Ok(serviciosDto);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error al obtener servicios");
            return StatusCode(500, "Error interno del servidor al obtener servicios.");
        }
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<ServicioDto>> GetServicio(int id)
    {
        if (id <= 0)
            return BadRequest("El ID del servicio debe ser un valor positivo.");

        try
        {
            var servicio = await _servicioService.GetByIdAsync(id);
            if (servicio == null)
                return NotFound($"No se encontró servicio con ID {id}");

            var servicioDto = _mapper.Map<ServicioDto>(servicio);

            return Ok(servicioDto);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error al obtener servicio con ID {Id}", id);
            return StatusCode(500, "Error interno del servidor al obtener servicio.");
        }
    }

    [HttpPost]
    public async Task<ActionResult<ServicioDto>> CreateServicio([FromBody] ServicioCreateDto servicioCreateDto)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        try
        {
            var servicio = _mapper.Map<Servicio>(servicioCreateDto);

            await _servicioService.AddAsync(servicio);

            var servicioDto = _mapper.Map<ServicioDto>(servicio);

            return CreatedAtAction(nameof(GetServicio), new { id = servicio.Id }, servicioDto);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error al crear servicio");
            return StatusCode(500, "Error interno del servidor al crear servicio.");
        }
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateServicio(int id, [FromBody] ServicioUpdateDto servicioUpdateDto)
    {
        if (id <= 0)
            return BadRequest("El ID del servicio debe ser un valor positivo.");

        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        try
        {
            var existingServicio = await _servicioService.GetByIdAsync(id);
            if (existingServicio == null)
                return NotFound($"No se encontró servicio con ID {id}");

            _mapper.Map(servicioUpdateDto, existingServicio);

            await _servicioService.UpdateAsync(existingServicio);

            return NoContent();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error al actualizar servicio con ID {Id}", id);
            return StatusCode(500, "Error interno del servidor al actualizar servicio.");
        }
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteServicio(int id)
    {
        if (id <= 0)
            return BadRequest("El ID del servicio debe ser un valor positivo.");

        try
        {
            var existingServicio = await _servicioService.GetByIdAsync(id);
            if (existingServicio == null)
                return NotFound($"No se encontró servicio con ID {id}");

            await _servicioService.DeleteAsync(id);

            return NoContent();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error al eliminar servicio con ID {Id}", id);
            return StatusCode(500, "Error interno del servidor al eliminar servicio.");
        }
    }
}
