﻿using AutoMapper;
public class MappingProfile : Profile
{
    public MappingProfile()
    {
        CreateMap<Cliente, ClienteDto>()
            .ForMember(dest => dest.ServicioNombre, opt => opt.MapFrom(src => src.Servicio != null ? src.Servicio.Nombre : null));
        CreateMap<ClienteCreateDto, Cliente>();
        CreateMap<ClienteUpdateDto, Cliente>();

        CreateMap<Servicio, ServicioDto>();
        CreateMap<ServicioCreateDto, Servicio>();
        CreateMap<ServicioUpdateDto, Servicio>();
    }
}

