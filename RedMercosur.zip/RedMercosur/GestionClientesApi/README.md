# GestionCliente
Requisitos previos
- .NET 8.0 SDK (o la versi�n que uses)
- Visual Studio 2022 o Visual Studio Code con extensiones C# (opcional pero recomendado)
- SQL Server o el motor de base datos que uses (si aplica) 2022
- Node.js y npm 

Para correr la APP
1) Abrir el SLN de la carpeta "GestionClientesApi"
	Corremos estos comandos
	dotnet restore
    dotnet build
    -Configurar el AppSetting.json con la el motor de base de datos que tenemos en nuestro entorno.
    -Crear la Base "GestionClientesDb"

	dotnet ef migrations add "nombremigracion"
    dotnet ef database update
2) Abrir el SLN de la carpeta "GestionClientesApi", levantamos la API
3) Abrimos el frontend "gestion-clientes-frontend" 
	npm run serve
 
    npm install
	(En caso que nos de error instalar el Axios)
	npm install axios


  

